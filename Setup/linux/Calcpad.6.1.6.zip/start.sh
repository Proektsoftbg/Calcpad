#!/bin/sh
dotnet /usr/share/calcpad/calcpad.dll